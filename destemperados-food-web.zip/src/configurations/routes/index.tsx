import AnonymousLayout from '../../layouts/anonymous';
import MainLayout from '../../layouts/main';

import HomePage from '../../pages/home';
import LoginPage from '../../pages/login';
import ProductsPage from '../../pages/products';
import NotFoundPage from '../../pages/notFound';

interface AppRole {
  name: string;
  policies: string[];
}

export interface AppRoute {
  path: string;
  name: string;
  routes: AppRoute[];
  component: () => React.ReactNode;
}

export type LayoutProps = {
  children?: React.ReactNode;
};

export interface AppLayoutRoute {
  layout: React.FC<LayoutProps>;
  routes: AppRoute[];
}

export const LayoutRoutes: AppLayoutRoute[] = [
  {
    layout: () => <MainLayout />,
    routes: [
      {
        path: '/',
        name: 'index',
        component: () => <HomePage />,
        routes: [],
      },
      {
        path: '/home',
        name: 'home',
        component: () => <HomePage />,
        routes: [],
      },
      {
        path: '/products',
        name: 'Products',
        component: () => <ProductsPage />,
        routes: [],
      },
    ],
  },
  {
    layout: () => <AnonymousLayout />,
    routes: [
      {
        path: '*',
        name: 'notFound',
        component: () => <NotFoundPage />,
        routes: [],
      },
      {
        path: '/login',
        name: 'login',
        component: () => <LoginPage />,
        routes: [],
      },
    ],
  },
];
