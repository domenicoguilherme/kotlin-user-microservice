import { BrowserRouter, Route, Routes as ReactRoutes } from 'react-router-dom';
import {
  LayoutRoutes,
  AppRoute,
  AppLayoutRoute,
} from './configurations/routes';
import flattenDeep from 'lodash/flattenDeep';

const generateFlattenRoutes = (routes: AppRoute[]): any => {
  if (!routes) return [];
  return flattenDeep(
    routes.map(({ routes: subRoutes, ...rest }) => [
      rest,
      generateFlattenRoutes(subRoutes),
    ]),
  );
};

export const renderRoutes = (mainRoutes: AppLayoutRoute[]) => {
  const Routes = () => {
    const layouts = mainRoutes.map(({ layout: Layout, routes }, index) => {
      const subRoutes: AppRoute[] = generateFlattenRoutes(routes);

      return (
        <Route key={index} element={<Layout />}>
          {subRoutes.map(({ component: Component, path, name }) => {
            return (
              Component &&
              path && <Route key={name} path={path} element={<Component />} />
            );
          })}
        </Route>
      );
    });

    return <ReactRoutes>{layouts}</ReactRoutes>;
  };

  return Routes();
};

const App = () => {
  const router = renderRoutes(LayoutRoutes);

  return <BrowserRouter>{router}</BrowserRouter>;
};

export default App;
