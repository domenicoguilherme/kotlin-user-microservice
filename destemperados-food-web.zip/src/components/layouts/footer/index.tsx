const Footer = () => {
  return <footer>Meu footer</footer>;
};

export default Footer;
