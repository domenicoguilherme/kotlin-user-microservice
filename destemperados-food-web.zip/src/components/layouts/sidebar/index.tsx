import { useEffect, useState } from 'react';

const Sidebar = ({ open }: { open: boolean }) => {
  const [sidebarClass, setSidebarClass] = useState<string>();

  useEffect(() => {
    const a = open ? '-translate-x-full' : '';
    setSidebarClass(
      `absolute bg-gray-800 text-white w-56 min-h-screen overflow-y-auto transition-transform transform ease-in-out duration-300 ${a}`,
    );
  }, [open, sidebarClass]);

  return (
    <div className={sidebarClass} id="sidebar">
      <div className="p-4">
        <h1 className="text-2xl font-semibold">Destemperados</h1>
        <ul className="mt-4">
          <li className="mb-2">
            <a href="/" className="block hover:text-indigo-400">
              Home
            </a>
          </li>
          <li className="mb-2">
            <a href="/products" className="block hover:text-indigo-400">
              Produtos
            </a>
          </li>
          <li className="mb-2">
            <a href="/login" className="block hover:text-indigo-400">
              Login
            </a>
          </li>
          <li className="mb-2">
            <a href="/support" className="block hover:text-indigo-400">
              Suporte
            </a>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default Sidebar;
