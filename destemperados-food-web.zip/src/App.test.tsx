import { describe, expect, it } from 'vitest';

// The two tests marked with concurrent will be run in parallel
describe('app', () => {
  it('example test', async () => {
    expect(1).toEqual(1);
  });
});
