import { Outlet } from 'react-router-dom';
import Footer from '../../components/layouts/footer';

const AnonymousLayout = () => {
  return (
    <>
      <Outlet />
      <Footer></Footer>
    </>
  );
};

export default AnonymousLayout;
