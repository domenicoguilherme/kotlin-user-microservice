import { Outlet } from 'react-router-dom';
import Header from '../../components/layouts/header';
import Sidebar from '../../components/layouts/sidebar';
import { useState } from 'react';
import Footer from '../../components/layouts/footer';

const MainLayout = () => {
  const [open, setOpen] = useState<boolean>(false);

  return (
    <div className="bg-gray-100">
      <div className="h-screen flex overflow-hidden bg-gray-200">
        <Sidebar open={open}></Sidebar>

        <div className="flex-1 flex flex-col overflow-hidden">
          <Header setOpen={setOpen} open={open} />
          <Outlet />
          <Footer />
        </div>
      </div>
    </div>
  );
};

export default MainLayout;
