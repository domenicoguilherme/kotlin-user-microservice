const ProductsPage = () => {
  return <>Products page</>;
};

export default ProductsPage;
