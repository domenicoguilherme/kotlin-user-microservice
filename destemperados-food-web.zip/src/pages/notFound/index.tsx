const NotFoundPage = () => {
  return <section>Página não encontrada</section>;
};

export default NotFoundPage;
