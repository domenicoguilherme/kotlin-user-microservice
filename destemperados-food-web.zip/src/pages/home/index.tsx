const HomePage = () => {
  return <>Página inicial</>;
};

export default HomePage;
