const LoginPage = () => {
  return <>Login page</>;
};

export default LoginPage;
